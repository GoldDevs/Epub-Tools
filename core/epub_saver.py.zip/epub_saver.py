import os
import zipfile
import shutil
import tempfile
import re
import hashlib
from pathlib import Path
from typing import Dict, Tuple, List, Optional
from .content_manager import ContentManager

class EPUBSaver:
    def __init__(self, content_manager: ContentManager):
        self.content_manager = content_manager
        self.backup_dir_name = "backups"
        self.max_backups = 5  # Mobile storage optimization
        self.default_compression_level = zipfile.ZIP_DEFLATED
        self.default_compresslevel = 6 # Balance between speed and size

    def save_epub(
        self, 
        original_path: Path,
        file_order: List[str],
        output_path: Optional[Path] = None, 
        create_backup: bool = True,
        compression: int = zipfile.ZIP_DEFLATED,
        compresslevel: int = 6
    ) -> Tuple[bool, str]:
        """Save modified EPUB with validation, backup, and correct file ordering."""
        if not output_path:
            output_path = original_path
            
        backup_path_str = "No backup created."
        if create_backup and output_path.exists():
            backup_path = self._create_backup(output_path)
            if not backup_path:
                return False, "Backup creation failed"
            backup_path_str = f"Backup created at {backup_path}"

        # Use temporary file for atomic saving
        temp_dir = tempfile.mkdtemp()
        temp_file_path = Path(temp_dir) / output_path.name
        
        try:
            with zipfile.ZipFile(temp_file_path, 'w') as target_zip:
                # **CRITICAL**: Write mimetype file first, uncompressed.
                mimetype_content = 'application/epub+zip'
                target_zip.writestr('mimetype', mimetype_content, compress_type=zipfile.ZIP_STORED)

                # Write all other files, using the original order
                for file_name in file_order:
                    if file_name == 'mimetype':
                        continue # Already written
                    
                    # Get content from the ContentManager (single source of truth for text)
                    if file_name in self.content_manager.content_map:
                        content = self.content_manager.get_content(file_name)
                        target_zip.writestr(file_name, content.encode('utf-8'), 
                                          compress_type=compression, compresslevel=compresslevel)
                    else:
                        # For binary files not in content_manager, copy from original
                        try:
                            with zipfile.ZipFile(original_path, 'r') as source_zip:
                                content_bytes = source_zip.read(file_name)
                                target_zip.writestr(file_name, content_bytes,
                                                  compress_type=compression, compresslevel=compresslevel)
                        except (KeyError, zipfile.BadZipFile):
                            # File was in original order but not in zip? Skip.
                            continue

            # Validate the new EPUB before replacing original
            if not self._validate_epub(temp_file_path):
                return False, "Validation failed after saving. The new file is corrupt."
                
            # Atomically move the new file into place
            shutil.move(temp_file_path, output_path)
            
            # Clear modified flags after successful save
            self.content_manager.modified_files.clear()
            self.content_manager.stats['modified_count'] = 0
            
            return True, f"Saved successfully. {backup_path_str}"
            
        except (OSError, zipfile.BadZipFile, zipfile.LargeZipFile) as e:
            return False, f"Save error: {str(e)}"
        finally:
            # Clean up the temporary directory
            shutil.rmtree(temp_dir, ignore_errors=True)

    def _create_backup(self, epub_path: Path) -> Optional[Path]:
        """Create backup with rotation."""
        if not epub_path.exists():
            return None
            
        backup_dir = epub_path.parent / self.backup_dir_name
        backup_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{epub_path.stem}_{timestamp}.epub.bak"
        backup_path = backup_dir / backup_name
        
        try:
            shutil.copy2(epub_path, backup_path)
            self._rotate_backups(backup_dir)
            return backup_path
        except OSError:
            return None

    def _rotate_backups(self, backup_dir: Path) -> None:
        """Rotate backups to prevent storage overflow."""
        backups = sorted(
            backup_dir.glob("*.bak"),
            key=os.path.getmtime,
            reverse=True
        )
        
        for backup in backups[self.max_backups:]:
            try:
                backup.unlink()
            except OSError:
                pass

    def _validate_epub(self, epub_path: Path) -> bool:
        """Basic EPUB validation checking for mimetype and container.xml."""
        if not epub_path.exists():
            return False
        try:
            with zipfile.ZipFile(epub_path, 'r') as test_zip:
                # Check required files
                namelist = test_zip.namelist()
                if 'mimetype' not in namelist or 'META-INF/container.xml' not in namelist:
                    return False
                    
                # Check mimetype is first and uncompressed
                info = test_zip.infolist()
                if not info or info[0].filename != 'mimetype' or info[0].compress_type != zipfile.ZIP_STORED:
                    return False
                    
                if test_zip.read('mimetype') != b'application/epub+zip':
                    return False
            return True
        except (zipfile.BadZipFile, KeyError, IndexError):
            return False

    def optimize_epub(self, original_path: Path, file_order: List[str]) -> Tuple[bool, str]:
        """Optimize EPUB file size by saving with max compression."""
        if not original_path.exists():
            return False, "Original file not found."
            
        original_size = original_path.stat().st_size
        
        # Save to a temporary path to compare size
        temp_optimized_path = original_path.with_suffix('.optimized.epub')
        
        success, message = self.save_epub(
            original_path=original_path,
            file_order=file_order,
            output_path=temp_optimized_path,
            create_backup=False, # Don't back up the original for an optimization check
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9 # Max compression
        )

        if not success:
            if temp_optimized_path.exists():
                temp_optimized_path.unlink()
            return False, f"Optimization failed during save: {message}"

        optimized_size = temp_optimized_path.stat().st_size

        if optimized_size < original_size:
            shutil.move(temp_optimized_path, original_path)
            return True, f"Optimized: {original_size/1024:.1f}KB -> {optimized_size/1024:.1f}KB"
        else:
            temp_optimized_path.unlink()
            return False, "No size reduction achieved."

    def verify_integrity(self, epub_path: Path) -> Dict[str, List[str]]:
        """Verify content integrity by comparing byte content."""
        results = {
            'missing_from_epub': [],
            'extra_in_epub': [],
            'mismatched_content': []
        }
        
        if not epub_path.exists():
            results['error'] = 'EPUB file not found'
            return results
            
        try:
            with zipfile.ZipFile(epub_path, 'r') as epub_zip:
                epub_files = set(epub_zip.namelist())
                manager_files = set(self.content_manager.content_map.keys())
                
                results['missing_from_epub'] = list(manager_files - epub_files)
                results['extra_in_epub'] = list(epub_files - manager_files)
                
                for file_name in manager_files & epub_files:
                    zip_content_bytes = epub_zip.read(file_name)
                    manager_content_bytes = self.content_manager.get_content(file_name).encode('utf-8')
                    
                    if zip_content_bytes != manager_content_bytes:
                        results['mismatched_content'].append(file_name)
            return results
        except (OSError, zipfile.BadZipFile) as e:
            return {'error': f'EPUB access failed: {e}'}